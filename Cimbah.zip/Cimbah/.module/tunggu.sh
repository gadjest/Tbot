#!/bin/sh
#warna
g='\033[1;92m'
c='\033[1;36m'
r='\033[1;91m'
re='\033[0m'

clear
echo $c' Tunggu Sebentar'$re'......\'
echo $g'•---------------------• '
echo $g'¦      '$c' loading      '$g' ¦'
echo $g'•---------------------• '
sleep 0.1
clear
echo $c' Tunggu Sebentar'$re'......|'
echo $g'•---------------------• '
echo $g'¦'$re'█'$c'      loading      '$g' ¦'
echo $g'•---------------------• '
sleep 0.1
clear
echo $c' Tunggu Sebentar'$re'....../'
echo $g'•---------------------• '
echo $g'¦'$re'██'$c'     loading      '$g' ¦'
echo $g'•---------------------• '
sleep 0.1
clear
echo $c' Tunggu Sebentar'$re'......-'
echo $g'•---------------------• '
echo $g'¦'$re'███'$c'    loading    '$g'   ¦'
echo $g'•---------------------• '
sleep 0.1
clear
echo $c' Tunggu Sebentar'$re'......\'
echo $g'•---------------------• '
echo $g'¦'$re'████'$c'   loading       '$g'¦'
echo $g'•---------------------• '
sleep 0.1
clear
echo $c' Tunggu Sebentar'$re'......|'
echo $g'•---------------------• '
echo $g'¦'$re'█████ '$c' loading      '$g' ¦'
echo $g'•---------------------• '
sleep 0.1
clear
echo $c' Tunggu Sebentar'$re'....../'
echo $g'•---------------------• '
echo $g'¦'$re'██████ '$c'loading'$g'       ¦'
echo $g'•---------------------• '
sleep 0.1
clear
echo $c' Tunggu Sebentar'$re'......-'
echo $g'•---------------------• '
echo $g'¦'$re'███████'$c'loading      '$g' ¦'
echo $g'•---------------------• '
sleep 0.1
clear
echo $c' Tunggu Sebentar'$re'......\'
echo $g'•---------------------• '
echo $g'¦'$re'████████'$c'oading'$g'       ¦'
echo $g'•---------------------• '
sleep 0.1
clear
echo $c' Tunggu Sebentar'$re'......|'
echo $g'•---------------------• '
echo $g'¦'$re'█████████'$c'ading'$g'       ¦'
echo $g'•---------------------• '
sleep 0.1
clear
echo $c' Tunggu Sebentar'$re'....../'
echo $g'•---------------------• '
echo $g'¦'$re'██████████'$c'ding'$g'       ¦'
echo $g'•---------------------•'
sleep 0.1
clear
echo $c' Tunggu Sebentar'$re'......-'
echo $g'•---------------------•'
echo $g'¦'$re'███████████'$c'ing      '$g' ¦'
echo $g'•---------------------•'
sleep 0.1
clear
echo $c' Tunggu Sebentar'$re'......\'
echo $g'•---------------------•'
echo $g'¦'$re'████████████'$c'ng'$g'       ¦'
echo $g'•---------------------•'
sleep 0.1
clear
echo $c' Tunggu Sebentar'$re'......|'
echo $g'•---------------------•'
echo $g'¦'$re'█████████████'$c'g '$g'      ¦'
echo $g'•---------------------•'
sleep 0.1
clear
echo $c' Tunggu Sebentar'$re'....../'
echo $g'•---------------------•'
echo $g'¦'$re'██████████████'$g'       ¦'
echo $g'•---------------------•'
sleep 0.1
clear
echo $c' Tunggu Sebentar'$re'......-'
echo $g'•---------------------•'
echo $g'¦'$re'███████████████ '$g'     ¦'
echo $g'•---------------------•'
sleep 0.1
clear
echo $c' Tunggu Sebentar'$re'......\'
echo $g'•---------------------•'
echo $g'¦'$re'████████████████     '$g'¦'
echo $g'•---------------------•'
sleep 0.1
clear
echo $c' Tunggu Sebentar'$re'......|'
echo $g'•---------------------•'
echo $g'¦'$re'█████████████████    '$g'¦'
echo $g'•---------------------•'
sleep 0.1
clear
echo $c' Tunggu Sebentar'$re'....../'
echo $g'•---------------------•'
echo $g'¦'$re'██████████████████   '$g'¦'
echo $g'•---------------------•'
sleep 0.1
clear
echo $c' Tunggu Sebentar'$re'......-'
echo $g'•---------------------•'
echo $g'¦'$re'███████████████████  '$g'¦'
echo $g'•---------------------•'
sleep 0.1
clear
echo $c' Tunggu Sebentar'$re'......\'
echo $g'•---------------------•'
echo $g'¦'$re'████████████████████ '$g'¦'
echo $g'•---------------------•'
sleep 0.1
clear
echo $c' Tunggu Sebentar'$re'......!'
echo $g'•---------------------•'
echo $g'¦'$re'█████████████████████'$g'¦'
echo $g'•---------------------•'

