#!/bin/sh
#warna
ab='\033[1;30m' #abu abu
lb='\033[1;34m' #light blue
lr='\033[1;31m' #light red
dg='\033[1;30m' #dark grey
lg='\033[1;92m' #light green
lc='\033[1;36m' #light cyan
y='\033[1;93m' #yellow
r='\033[0;31m' #red
brw='\033[0;33m' #brown
w='\033[1;0m'

echo $lb'   ██████▒'
echo $lb'  ▓███████'$y'           ▄▄                  ▄▄'
echo $lb' ▒███▒  ░█'$y'           ██                  ██'
echo $lb' ████▓    '$y' ████▄██▄  ██▄███▄    ▄█████▄  ██▄████▄'
echo $lb' ████░    '$y' ██ ██ ██  ██▀  ▀██   ▀ ▄▄▄██  ██▀   ██'
echo $lb'█████     '$y' ██ ██ ██  ██    ██  ▄██▀▀▀██  ██    ██'
echo $lb'█████     '$y' ██ ██ ██  ███▄▄██▀  ██▄▄▄███  ██    ██'
echo $lb' ████░     '$brw'▀▀ ▀▀ ▀▀  ▀▀ ▀▀▀     ▀▀▀▀ ▀▀  ▀▀    ▀▀'
echo $lb' ████▓    '$dg' #######################################'
echo $lb' ▒███▒  ░█'$dg' ##'$lg' Author   : Kadal-15  '$r'    ©kadal-15'$dg'##'
echo $lb'  ▓███████ '$dg'## '$lg'Whatsapp : 085336117892 '$r' v 1.9.7 '$dg' ##'
echo $lb'   ▒█████▒ '$dg'## '$lg'Team     : KadalCyber            '$dg' ##'
echo $dg'           #######################################\n'
echo $lg'======================<'$w'Welocome To Si Mbah Tools'$lg'>==================\n'
